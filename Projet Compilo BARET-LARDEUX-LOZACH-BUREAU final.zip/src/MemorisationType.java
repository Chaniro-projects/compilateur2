public class MemorisationType implements Constante {
	private eType type;
	
	public MemorisationType() {
	}
	
	public eType getType() {
		return this.type;
	}
	
	public void setType(eType t) {
		this.type = t;
	}
}