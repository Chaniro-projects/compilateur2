public interface Constante {
	public static int TRUE = -1;
	public static int FALSE = 0;
	
	public static enum eType {
		BOOLEEN,
		ENTIER,
		ERREUR
	}
	
	public static enum eOperande {
		ADD,
		SUB,
		MUL,
		DIV,
		INF,
		INFEGAL,
		SUP,
		SUPEGAL,
		EGAL,
		DIFF,
		AND,
		OR,
		NOT,
		NEG
	}
}